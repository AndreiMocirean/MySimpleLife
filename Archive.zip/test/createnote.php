<?php
    session_start();
    require("header.php");
    require("mysql_connect.php");
    $companie = $job = $descriere = $angajatacum = $salariu = $experienta = $comentarii = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $companie = htmlspecialchars($_POST["companie"]);
        $job = htmlspecialchars($_POST["job"]);
        $descriere = htmlspecialchars($_POST["descriere"]);
        $salariu = htmlspecialchars($_POST["salariu"]);
        $angajatacum = htmlspecialchars($_POST["angajatacum"]);
        $experienta = htmlspecialchars($_POST["experienta"]);
        $comentarii = htmlspecialchars($_POST["comentarii"]);
        $id=$_SESSION["user_id"];

        if (!empty($companie) && !empty($job) && !empty($descriere) && !empty($salariu) && !empty($angajatacum) && !empty($experienta) && !empty($comentarii)) {
            $sql = "INSERT INTO notes(companie, job, descriere, salariu, angajatacum, experienta, comentarii, userid) VALUES ('$companie','$job','$descriere','$salariu','$angajatacum','$experienta','$comentarii','$id')";

            if ($conn->query($sql) === TRUE) {
                echo '<div class="alert alert-success" role="alert">
                        Record updated successfully.
                      </div>';
            } else {
                echo '<div class="alert alert-danger" role="alert">
                        An error occurred while updating.<br>
                        Error:  '.$sql.' <br>  '.$conn->error.'
                      </div>';
            }
        }
        $conn->close();
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSL | Notes</title>
    <link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="notes.php">My Notes</a>
        </div>
    </nav>

    <div class="container">
        <div class="row pt-3">
            <div class="col">
                <div class="card">
                    <span>
                    <h1> <a class="m-2" href="shopping.php">⬅︎</a></h1>
                    <h1 class="card-title text-center">CREATE A NEW TASK</h5>
                    </span>
                        <div class="card-body">
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                <div class="mb-3">
                                    <label for="companie" class="form-label">Numele Companiei</label>
                                    <input type="text" class="form-control" id="companie" name="companie" placeholder="Numele Companiei la care ai lucrat sau lucrezi" required />
                                </div>
                                <div class="mb-3">
                                    <label for="job" class="form-label">Numele Postului</label>
                                    <input type="text" class="form-control" id="job" name="job" placeholder="Numele Job-ului pe care il ai sau l-ai avut in cadrul companiei" required />
                                </div>
                                <div class="mb-3">
                                    <label for="descriere" class="form-label">Descrierea Job-ului</label>
                                    <textarea class="form-control" id="descriere" name="descriere" placeholder="Descrie in cateva randuri obligatiile si indatoririle tale la locul de munca." rows="3" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="descriere" class="form-label">Pachet Salarial</label>
                                    <textarea class="form-control" id="salariu" name="salariu" placeholder="Pachetul salarial ramane confidential. Numele tau nu va aparea nicaieri." rows="1" required></textarea>
                                </div>

                                <label for="angajatacum" class="form-label">Esti inca angajat aici?</label>
                                <select class="form-select" name="angajatacum" required>
                                    <option selected hidden>Selecteaza o optiune..</option>
                                    <option value="Da">Da</option>
                                    <option value="Nu">Nu</option>
                                </select>
                                <label for="experienta" class="form-label">Cum a fost experienta ta in companie?</label>
                                <select class="form-select" name="experienta" required>
                                    <option selected hidden>Selecteaza o optiune..</option>
                                    <option value="Buna">Buna</option>
                                    <option value="Rea">Rea</option>
                                    <option value="Depinde de situatie">Depinde de situatie</option>
                                </select>
                                <div class="mb-3">
                                    <label for="comentarii" class="form-label">Comentarii</label>
                                    <textarea class="form-control" id="comentarii" name="comentarii" placeholder="Ai ceva de adaugat acestui mic review? Aici e locul perfect pentru a o face!" rows="3" required></textarea>
                                </div>
                                <div class="d-grid gap-2 pt-4">
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>
                </div>
            </div>
        </div>
    </div>

</body>


</html>
